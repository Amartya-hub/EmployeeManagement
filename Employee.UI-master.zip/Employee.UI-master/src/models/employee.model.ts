export interface Employee{
    employeeCode: number;
    employeeName: string;
    dateOfBirth: string;
    gender: string;
    department: string;
    designation: string;
    basicSalary: number;
}